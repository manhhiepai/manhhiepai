
import React, { useRef, useEffect, useState } from 'react';
import { UserProfile } from '../types';

interface Props {
  onSubmit: (profile: UserProfile) => void;
}

export const InputSection: React.FC<Props> = ({ onSubmit }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasDrawn, setHasDrawn] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [showTerms, setShowTerms] = useState(false);
  const [warningCount, setWarningCount] = useState(0);
  const [showWarningModal, setShowWarningModal] = useState(false);
  
  const [formData, setFormData] = React.useState<UserProfile>({
    fullName: '',
    birthDate: '',
    birthTime: '',
    gender: 'Nữ',
    seeking: 'Nam',
    interests: '',
    personality: ''
  });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.lineJoin = 'round';
        ctx.lineCap = 'round';
        ctx.lineWidth = 2;
        ctx.strokeStyle = '#c5a059'; 
      }
    }
  }, []);

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    setIsDrawing(true);
    setHasDrawn(true);
    draw(e);
  };

  const stopDrawing = () => {
    setIsDrawing(false);
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      ctx?.beginPath();
    }
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = ('touches' in e) ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = ('touches' in e) ? e.touches[0].clientY - rect.top : e.clientY - rect.top;

    ctx.lineTo(x, y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (canvas && ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      setHasDrawn(false);
    }
  };

  const handleCheckboxClick = (e: React.MouseEvent) => {
    if (warningCount < 2) {
      e.preventDefault();
      setShowWarningModal(true);
    }
  };

  const handleWarningAcknowledge = () => {
    setWarningCount(prev => prev + 1);
    setShowWarningModal(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName || !formData.birthDate) {
      alert("Vui lòng cung cấp đầy đủ thông tin định danh.");
      return;
    }
    if (!agreed) {
      alert("Bạn cần xác nhận sự đồng thuận với các điều khoản pháp lý của Keyempay.");
      return;
    }

    const canvas = canvasRef.current;
    const handwritingData = canvas ? canvas.toDataURL('image/png').split(',')[1] : undefined;
    
    onSubmit({
      ...formData,
      handwritingData
    });
  };

  const inputClass = "w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#c5a059] transition-all font-light";
  const labelClass = "block text-[11px] uppercase tracking-[0.2em] text-[#c5a059] font-medium mb-2 mt-4";

  return (
    <div className="max-w-3xl mx-auto glass p-8 md:p-14 rounded-2xl shadow-3xl relative">
      {/* Warning Modal - Rebranded for Professionalism */}
      {showWarningModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/95 backdrop-blur-xl">
          <div className="border border-[#c5a059]/30 w-full max-w-xl p-12 rounded-lg text-center animate-in zoom-in-95 duration-300">
            <div className="w-24 h-24 border border-[#c5a059]/20 rounded-full flex items-center justify-center mx-auto mb-8">
              <span className="text-4xl gold-gradient font-serif">!</span>
            </div>
            <h3 className="text-4xl font-serif mb-6 gold-gradient uppercase tracking-tight">
              {warningCount === 0 ? "Xác thực Ý thức" : "Cam kết Dữ liệu"}
            </h3>
            <p className="text-xl font-light text-white/80 mb-10 leading-relaxed italic">
              {warningCount === 0 
                ? "CHÚNG TÔI YÊU CẦU BẠN PHẢI THẤU HIỂU MỌI ĐIỀU KHOẢN TRƯỚC KHI TRUY XUẤT HỆ THỐNG." 
                : "HỆ THỐNG DỰA TRÊN THUẬT TOÁN ĐA TẦNG. BẠN CẦN CHỊU TRÁCH NHIỆM VỚI CÁC QUYẾT ĐỊNH CÁ NHÂN SAU KHI XEM KẾT QUẢ."}
            </p>
            <button 
              onClick={handleWarningAcknowledge} 
              className="w-full py-5 border border-[#c5a059] hover:bg-[#c5a059] hover:text-black text-[#c5a059] font-bold text-sm tracking-[0.3em] uppercase rounded-none transition-all duration-500"
            >
              TIẾP TỤC XÁC THỰC
            </button>
          </div>
        </div>
      )}

      {showTerms && (
        <div className="fixed inset-0 z-[90] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="bg-[#0f0f11] border border-white/10 w-full max-w-2xl max-h-[85vh] overflow-y-auto p-10 rounded-lg shadow-2xl relative">
            <button onClick={() => setShowTerms(false)} className="absolute top-6 right-6 text-white/40 hover:text-[#c5a059] transition-colors">✕</button>
            <h3 className="text-3xl font-serif mb-8 gold-gradient">Hiệp Định Dịch Vụ Keyempay AI</h3>
            <div className="text-sm text-white/60 space-y-6 leading-relaxed font-light text-justify">
              <section>
                <p className="font-semibold text-[#c5a059] mb-2 uppercase tracking-widest text-[10px]">Cập nhật: 01/01/2026</p>
                <p>Keyempay vận hành dựa trên các mô hình xác suất và phân tích nhân trắc học tiên tiến. Bằng cách sử dụng hệ thống, bạn cam kết tuân thủ các quy chuẩn bảo mật và đạo đức dữ liệu của chúng tôi.</p>
              </section>

              <section>
                <h4 className="font-bold text-white mb-2 uppercase tracking-wider text-[11px]">1. Phạm vi phân tích</h4>
                <p>Dịch vụ thực hiện đối soát dữ liệu Thần số học, Chiêm tinh và Bút tích học để tìm ra các điểm tương đồng trong tần số rung động linh hồn. Kết quả phản ánh các xu hướng xác suất cao nhất.</p>
              </section>

              <section>
                <h4 className="font-bold text-white mb-2 uppercase tracking-wider text-[11px]">2. Quyền riêng tư</h4>
                <p>Toàn bộ thông tin định danh và dữ liệu nét bút được mã hóa 256-bit và xóa bỏ sau mỗi chu kỳ manifest để đảm bảo tính tuyệt mật cho người dùng.</p>
              </section>

              <section>
                <h4 className="font-bold text-white mb-2 uppercase tracking-wider text-[11px]">3. Giới hạn trách nhiệm</h4>
                <p>Keyempay cung cấp góc nhìn dựa trên trí tuệ nhân tạo và huyền học cổ điển. Chúng tôi không chịu trách nhiệm pháp lý cho các hành vi dân sự của người dùng dựa trên thông tin được cung cấp.</p>
              </section>
            </div>
            <button 
              onClick={() => setShowTerms(false)} 
              className="mt-10 w-full py-4 bg-white text-black font-bold uppercase tracking-[0.2em] text-xs hover:bg-[#c5a059] transition-all"
            >
              XÁC NHẬN ĐỒNG THUẬN
            </button>
          </div>
        </div>
      )}

      <div className="text-center mb-12">
        <h2 className="text-5xl font-serif gold-gradient mb-2">Keyempay Manifesto</h2>
        <div className="flex items-center justify-center space-x-3">
          <span className="h-[1px] w-8 bg-[#c5a059]/30"></span>
          <p className="text-white/30 text-[9px] uppercase tracking-[0.5em] font-medium">Hệ thống phân tích cao cấp</p>
          <span className="h-[1px] w-8 bg-[#c5a059]/30"></span>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className={labelClass}>Danh tính đầy đủ</label>
            <input 
              type="text" 
              placeholder="Ex: Alexander Nguyen" 
              className={inputClass}
              value={formData.fullName}
              onChange={e => setFormData({...formData, fullName: e.target.value})}
            />
          </div>
          <div>
            <label className={labelClass}>Chu kỳ sinh nhật</label>
            <input 
              type="date" 
              className={inputClass}
              value={formData.birthDate}
              onChange={e => setFormData({...formData, birthDate: e.target.value})}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className={labelClass}>Giờ hiện hữu</label>
            <input 
              type="time" 
              className={inputClass}
              value={formData.birthTime}
              onChange={e => setFormData({...formData, birthTime: e.target.value})}
            />
          </div>
          <div>
            <label className={labelClass}>Giới tính</label>
            <select 
              className={inputClass}
              value={formData.gender}
              onChange={e => setFormData({...formData, gender: e.target.value})}
            >
              <option value="Nam">Nam</option>
              <option value="Nữ">Nữ</option>
              <option value="Linh hoạt">Linh hoạt</option>
            </select>
          </div>
          <div>
            <label className={labelClass}>Tìm kiếm</label>
            <select 
              className={inputClass}
              value={formData.seeking}
              onChange={e => setFormData({...formData, seeking: e.target.value})}
            >
              <option value="Nam">Nam</option>
              <option value="Nữ">Nữ</option>
            </select>
          </div>
        </div>

        <div className="mt-8">
          <label className={labelClass}>
            Năng lượng bút tích (Graphology Analysis)
            <span className="block text-[10px] text-white/20 font-light mt-1 normal-case tracking-normal italic">
              Hãy ký tên hoặc vẽ một biểu tượng đại diện cho tinh thần của bạn.
            </span>
          </label>
          <div className="relative group overflow-hidden rounded-lg">
            <canvas
              ref={canvasRef}
              width={600}
              height={180}
              onMouseDown={startDrawing}
              onMouseUp={stopDrawing}
              onMouseMove={draw}
              onMouseOut={stopDrawing}
              onTouchStart={startDrawing}
              onTouchEnd={stopDrawing}
              onTouchMove={draw}
              className="w-full bg-white/[0.02] border border-white/10 cursor-crosshair touch-none"
            />
            <button
              type="button"
              onClick={clearCanvas}
              className="absolute bottom-4 right-4 px-3 py-1.5 border border-white/10 text-[9px] uppercase tracking-widest hover:border-[#c5a059] transition-all"
            >
              Reset Canvas
            </button>
          </div>
        </div>

        <div className="pt-8 flex items-start space-x-4">
          <input 
            id="terms"
            type="checkbox" 
            checked={agreed}
            onChange={(e) => setAgreed(e.target.checked)}
            onClick={handleCheckboxClick}
            className={`w-5 h-5 mt-1 border-[#c5a059] bg-transparent text-[#c5a059] focus:ring-0 cursor-pointer transition-all ${warningCount < 2 ? 'opacity-30' : ''}`}
          />
          <label htmlFor="terms" className="text-[10px] text-white/40 leading-relaxed cursor-pointer font-light">
            TÔI XÁC NHẬN RẰNG ĐÃ ĐỌC VÀ CHẤP THUẬN TOÀN BỘ <button type="button" onClick={() => setShowTerms(true)} className="text-[#c5a059] font-bold hover:underline">HIỆP ĐỊNH DỊCH VỤ</button> CỦA KEYEMPAY. MỌI DỮ LIỆU CUNG CẤP LÀ HOÀN TOÀN CHÍNH XÁC.
          </label>
        </div>

        <button 
          type="submit"
          className="w-full mt-8 bg-white text-black font-bold py-5 rounded-none shadow-2xl hover:bg-[#c5a059] transition-all duration-500 uppercase tracking-[0.4em] text-xs"
        >
          Kích Hoạt Thuật Toán Manifest
        </button>
      </form>
    </div>
  );
};
