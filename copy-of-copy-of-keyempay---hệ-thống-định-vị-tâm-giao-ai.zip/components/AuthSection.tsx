
import React, { useState } from 'react';
import { dbService } from '../services/dbService';

interface Props {
  onSuccess: () => void;
}

export const AuthSection: React.FC<Props> = ({ onSuccess }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password || (!isLogin && !name)) {
      alert("Hệ thống yêu cầu đầy đủ các tham số định danh.");
      return;
    }

    setLoading(true);
    try {
      if (isLogin) {
        const res = await dbService.login(email, password);
        if (res.success) {
          onSuccess();
        } else {
          alert(res.message);
        }
      } else {
        const res = await dbService.register(name, email, password);
        if (res.success) {
          alert("Ghi danh thành công. Vui lòng đăng nhập.");
          setIsLogin(true);
        } else {
          alert(res.message);
        }
      }
    } catch (err) {
      alert("Lỗi kết nối cơ sở dữ liệu.");
    } finally {
      setLoading(false);
    }
  };

  const inputClass = "w-full bg-white/5 border border-white/10 rounded-none px-4 py-4 text-white focus:outline-none focus:border-[#c5a059] transition-all font-light placeholder-white/20 disabled:opacity-50";
  const labelClass = "block text-[10px] uppercase tracking-[0.3em] text-[#c5a059] font-medium mb-2 mt-6";

  return (
    <div className="max-w-md mx-auto animate-in fade-in zoom-in-95 duration-700">
      <div className="glass p-10 md:p-14 rounded-none border border-white/10 shadow-2xl relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-16 h-16 border-t border-r border-[#c5a059]/30"></div>
        <div className="absolute bottom-0 left-0 w-8 h-8 border-b border-l border-[#c5a059]/30"></div>
        
        <div className="text-center mb-10">
          <h2 className="text-4xl font-serif gold-gradient mb-2">
            {isLogin ? "Khởi tạo Truy cập" : "Kiến tạo Tài khoản"}
          </h2>
          <p className="text-[9px] text-white/30 uppercase tracking-[0.4em]">
            Hệ thống nhận diện định mệnh Keyempay
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <div>
              <label className={labelClass}>Danh tính đầy đủ</label>
              <input 
                type="text" 
                placeholder="Ex: Alexander Nguyen" 
                className={inputClass}
                value={name}
                onChange={e => setName(e.target.value)}
                disabled={loading}
              />
            </div>
          )}
          
          <div>
            <label className={labelClass}>Địa chỉ định danh (Email)</label>
            <input 
              type="email" 
              placeholder="name@archivedestiny.com" 
              className={inputClass}
              value={email}
              onChange={e => setEmail(e.target.value)}
              disabled={loading}
            />
          </div>

          <div>
            <label className={labelClass}>Mật mã bảo mật</label>
            <input 
              type="password" 
              placeholder="••••••••" 
              className={inputClass}
              value={password}
              onChange={e => setPassword(e.target.value)}
              disabled={loading}
            />
          </div>

          <div className="pt-8">
            <button 
              type="submit"
              disabled={loading}
              className="w-full bg-white text-black font-bold py-5 hover:bg-[#c5a059] transition-all duration-500 uppercase tracking-[0.4em] text-xs flex items-center justify-center space-x-2"
            >
              {loading ? (
                <span className="w-4 h-4 border-2 border-black/20 border-t-black rounded-full animate-spin"></span>
              ) : (
                <span>{isLogin ? "Truy cập Archive" : "Hoàn tất Ghi danh"}</span>
              )}
            </button>
          </div>
        </form>

        <div className="mt-10 text-center">
          <button 
            type="button"
            onClick={() => setIsLogin(!isLogin)}
            className="text-[10px] text-white/40 uppercase tracking-[0.2em] hover:text-[#c5a059] transition-colors"
          >
            {isLogin 
              ? "Chưa có quyền truy cập? Đăng ký ngay" 
              : "Đã có danh tính trong hệ thống? Đăng nhập"}
          </button>
        </div>
      </div>
      
      <p className="mt-8 text-center text-[9px] text-white/20 uppercase tracking-[0.3em] italic leading-loose">
        Kết nối cơ sở dữ liệu an toàn • SSL 256-bit Encrypted<br/>
        Keyempay Global Database Infrastructure
      </p>
    </div>
  );
};
