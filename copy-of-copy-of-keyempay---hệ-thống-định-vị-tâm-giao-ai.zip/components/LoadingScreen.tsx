
import React from 'react';

const steps = [
  "Đang truy cập kho lưu trữ tinh tú...",
  "Đồng bộ hóa dữ liệu Thần số học Pytago...",
  "Phân tích rung động nét vẽ tiềm thức...",
  "Kiến tạo cấu trúc chân dung tâm giao...",
  "Hoàn tất quá trình manifest dữ liệu..."
];

export const LoadingScreen: React.FC = () => {
  const [currentStep, setCurrentStep] = React.useState(0);

  React.useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStep(prev => (prev + 1) % steps.length);
    }, 3500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] space-y-12">
      <div className="relative">
        <div className="w-40 h-40 border-[1px] border-[#c5a059]/10 border-t-[#c5a059] rounded-full animate-spin"></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-2 h-2 bg-[#c5a059] rounded-full shadow-[0_0_20px_#c5a059] animate-pulse"></div>
        </div>
      </div>
      <div className="text-center space-y-6 max-w-md">
        <p className="text-xl font-serif gold-gradient uppercase tracking-widest h-8">
          {steps[currentStep]}
        </p>
        <p className="text-white/20 text-[10px] uppercase tracking-[0.3em] font-light italic">
          Vũ trụ đang xử lý các chuỗi mã định mệnh dành cho bạn...
        </p>
      </div>
    </div>
  );
};
