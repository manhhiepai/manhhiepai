
import React from 'react';
import { PredictionResult } from '../types';

interface Props {
  prediction: PredictionResult;
  imageUrl: string;
  onReset: () => void;
}

export const ResultDisplay: React.FC<Props> = ({ prediction, imageUrl, onReset }) => {
  return (
    <div className="max-w-6xl mx-auto p-4 md:p-10 space-y-16 animate-in fade-in duration-1000">
      {/* Brand Badge */}
      <div className="flex flex-col items-center">
        <div className="px-6 py-2 border border-[#c5a059]/30 rounded-full mb-4">
          <span className="text-[10px] gold-gradient uppercase tracking-[0.5em] font-bold">Official Manifest Analysis</span>
        </div>
        <h2 className="text-6xl font-serif gold-gradient italic">Keyempay Archive</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start">
        {/* Left Column: The Portrait */}
        <div className="lg:col-span-5 flex flex-col items-center">
          <div className="relative w-full max-w-md group">
            <div className="absolute -inset-1 bg-gradient-to-r from-[#c5a059] to-[#f1e4b3] rounded-lg blur opacity-20 group-hover:opacity-40 transition duration-1000"></div>
            <div className="relative bg-[#0a0a0c] p-1 border border-white/10 rounded-lg">
              <div className="bg-[#f5f5f5] p-2">
                 <img 
                  src={imageUrl} 
                  alt="Destined Soulmate Portrait" 
                  className="w-full h-auto grayscale contrast-125 brightness-110 shadow-inner"
                />
              </div>
            </div>
            
            <div className="absolute -bottom-6 -right-6 bg-[#c5a059] text-black p-4 rounded-full w-24 h-24 flex flex-col items-center justify-center shadow-2xl">
              <span className="text-2xl font-black">{prediction.compatibilityScore}%</span>
              <span className="text-[8px] font-bold uppercase tracking-tighter">Match rate</span>
            </div>
          </div>

          <div className="mt-20 w-full space-y-4">
            <div className="flex justify-between border-b border-white/5 pb-2">
              <span className="text-[10px] text-white/40 uppercase tracking-widest">Model Accuracy</span>
              <span className="text-[10px] text-[#c5a059] font-bold">98.4% Confidence</span>
            </div>
            <div className="flex justify-between border-b border-white/5 pb-2">
              <span className="text-[10px] text-white/40 uppercase tracking-widest">Data Clusters</span>
              <span className="text-[10px] text-[#c5a059] font-bold">1.2M Samples</span>
            </div>
          </div>
        </div>

        {/* Right Column: Deep Insights */}
        <div className="lg:col-span-7 space-y-10">
          <div className="space-y-4">
            <h4 className="text-sm font-bold gold-gradient uppercase tracking-[0.3em]">Chân dung nhận diện</h4>
            <p className="text-2xl font-serif text-white/90 leading-relaxed italic border-l-2 border-[#c5a059]/30 pl-6">
              "{prediction.loverDescription}"
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="glass p-6 rounded-none border-l-4 border-l-[#c5a059]">
              <h4 className="text-[10px] font-bold text-white uppercase tracking-widest mb-4">Số học chủ đạo</h4>
              <p className="text-xs text-white/50 leading-relaxed font-light">{prediction.numerologyReading}</p>
            </div>
            <div className="glass p-6 rounded-none border-l-4 border-l-[#c5a059]">
              <h4 className="text-[10px] font-bold text-white uppercase tracking-widest mb-4">Mật mã tinh tú</h4>
              <p className="text-xs text-white/50 leading-relaxed font-light">{prediction.astrologyInsight}</p>
            </div>
          </div>

          <div className="glass p-8 rounded-none bg-white/[0.01]">
            <h4 className="text-[10px] font-bold gold-gradient uppercase tracking-widest mb-4 flex items-center">
              Phân tích Bút tích học (AI Deep Scan)
            </h4>
            <p className="text-sm text-white/70 leading-relaxed font-light italic">
              Dựa trên áp lực và độ nghiêng của nét vẽ, hệ thống nhận diện: {prediction.graphologyInsight}
            </p>
          </div>

          <div className="space-y-4">
            <h4 className="text-[10px] font-bold text-white uppercase tracking-widest">Thời điểm hội ngộ</h4>
            <p className="text-sm text-white/60 leading-relaxed font-light">{prediction.meetingStory}</p>
          </div>

          <div className="pt-10">
            <button 
              onClick={onReset}
              className="w-full py-5 border border-white/10 hover:border-[#c5a059] text-white/40 hover:text-[#c5a059] text-[10px] font-bold transition-all uppercase tracking-[0.5em]"
            >
              Thực hiện Manifest lượt mới
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
