
// ĐÂY LÀ NƠI BẠN KẾT NỐI VỚI BACKEND
// Thay URL này bằng địa chỉ Server API của bạn (ví dụ: http://localhost:5000)
const API_URL = "https://your-backend-api.com"; 

export const dbService = {
  register: async (name: string, email: string, pass: string): Promise<{success: boolean, message: string}> => {
    try {
      const response = await fetch(`${API_URL}/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, pass })
      });
      return await response.json();
    } catch (error) {
      return { success: false, message: "Không thể kết nối đến máy chủ." };
    }
  },

  login: async (email: string, pass: string): Promise<{success: boolean, user?: any, message: string}> => {
    try {
      const response = await fetch(`${API_URL}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, pass })
      });
      return await response.json();
    } catch (error) {
      return { success: false, message: "Lỗi đăng nhập hệ thống." };
    }
  }
};
