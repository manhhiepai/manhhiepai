
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { UserProfile, PredictionResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generatePrediction = async (profile: UserProfile): Promise<PredictionResult> => {
  const textContent = {
    text: `
      HỆ THỐNG PHÂN TÍCH KEYEMPAY AI (Bản cập nhật v2.5):
      Dữ liệu đầu vào đã được huấn luyện qua:
      - 1,2 triệu hồ sơ Thần số học Pytago (Số chủ đạo, Chỉ số linh hồn, Sứ mệnh).
      - Cơ sở dữ liệu Chiêm tinh học phương Tây (Vị trí tinh tú, Cung mọc, Điểm tương hợp).
      - Thuật toán nhận diện Bút tích học (Phân tích áp lực nét bút, độ nghiêng, và năng lượng tâm linh qua hình ảnh).

      YÊU CẦU: Phân tích hồ sơ và hình ảnh nét vẽ kèm theo để tìm ra chân dung tâm giao.
      Hồ sơ:
      - Tên: ${profile.fullName}
      - Ngày sinh: ${profile.birthDate}
      - Giờ sinh: ${profile.birthTime || 'Không xác định'}
      - Mong muốn tìm: ${profile.seeking}

      CHỈ THỊ QUAN TRỌNG:
      1. KHÔNG dự đoán tên của người ấy.
      2. Mô tả sâu sắc về tính cách và "khuôn mặt" (để làm dữ liệu tạo ảnh).
      3. Giải mã Bút tích học: Nét vẽ của người dùng tiết lộ điều gì về khao khát tiềm thức của họ?
      4. Tạo ra một visual prompt chỉ tập trung vào GƯƠNG MẶT (Face only headshot).
    `
  };

  const contents: any[] = [textContent];
  
  if (profile.handwritingData) {
    contents.push({
      inlineData: {
        mimeType: 'image/png',
        data: profile.handwritingData
      }
    });
  }

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: { parts: contents },
    config: {
      systemInstruction: `Bạn là hệ thống Keyempay AI chuyên nghiệp. Bạn được huấn luyện để phân tích con người qua Số học, Tinh tú và Nét bút. 
      Ngôn ngữ: Tiếng Việt. Phong cách: Sâu sắc, huyền bí, nhưng đáng tin cậy. 
      CẤM: Dự đoán tên người. 
      BẮT BUỘC: Trả về JSON theo schema.`,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          loverDescription: { type: Type.STRING },
          numerologyReading: { type: Type.STRING },
          astrologyInsight: { type: Type.STRING },
          graphologyInsight: { type: Type.STRING },
          meetingStory: { type: Type.STRING },
          compatibilityScore: { type: Type.NUMBER },
          visualPrompt: { type: Type.STRING }
        },
        required: ["loverDescription", "numerologyReading", "astrologyInsight", "graphologyInsight", "meetingStory", "compatibilityScore", "visualPrompt"]
      }
    }
  });

  return JSON.parse(response.text);
};

export const generateLoverImage = async (visualPrompt: string, seeking: string): Promise<string> => {
  const genderContext = seeking === 'Nam' ? 'A man' : seeking === 'Nữ' ? 'A woman' : 'A person';
  
  // Strict "Face Only" and "Sketch Style"
  const fullPrompt = `An extreme close-up headshot portrait, ONLY THE FACE, focusing on facial features and expression of ${genderContext}. 
    Style: Hyper-realistic pencil sketch, fine charcoal drawing on ivory paper, soft graphite shading, grayscale, monochrome art. 
    The face should fill the entire frame. Detailed eyes, lips, and skin texture in a sketch medium. 
    Description: ${visualPrompt}. Professional artistic drawing, high contrast, clean white background. No shoulders, no clothes visible.`;

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [{ text: fullPrompt }]
    },
    config: {
      imageConfig: {
        aspectRatio: "1:1"
      }
    }
  });

  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }

  throw new Error("Image generation failed");
};
